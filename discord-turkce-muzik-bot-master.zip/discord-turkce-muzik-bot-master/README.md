# discord-turkce-muzik-bot
Github'da yayınlanan ilk Türkçe, Discord müzik botu